<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'notification-types' );
$this->load_plugin_settings( 'event-alerts' );
$this->load_plugin_settings( 'daily-reporting' );
